# Inviting English Tutor — animated avatar

This pack contains a 9-frame looping GIF and individual PNG frames.

## Visual direction
Adult blonde female English tutor, chest-up composition, confident friendly expression, neon-blue headphones, warm rim light, microphone, London night background. The framing intentionally shows shoulders and upper chest while remaining tasteful and suitable for a language-learning app.

## Files
- `tutor-inviting.gif` — ready-to-use looping animation (9 frames, 180 ms/frame)
- `frame-01.png` ... `frame-09.png` — individual frames for custom animation or canvas rendering

## Suggested use
Use the GIF as a quick drop-in preview. For app integration, prefer the PNG frames if you want to synchronize mouth motion with TTS playback:
- show frames 1–4 while speech audio is playing
- show frames 5–7 for a smile / positive response
- show frames 8–9 as a calm listening / idle pose

The GIF loops continuously, so it is best for a decorative preview. For a real tutor that should stop when audio ends, use the individual PNG frames and control playback from the app's audio `play` / `ended` events.

All frames are 416×416 px. Keep `object-fit: contain` (not `cover`) to avoid cropping the shoulders and upper torso.
